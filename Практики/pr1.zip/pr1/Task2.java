package pr1;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.FutureTask;

public class Task2 {
    public static void main(String[] args) {
        Random random = new Random();
        ArrayList<Integer> list = new ArrayList<>();
        Scanner s = new Scanner(System.in);
        do {
            int next_int = s.nextInt();
            list.add(next_int);
            FutureTask future = new FutureTask(() ->
                {
                    int time = random.nextInt(4000) + 1000;
                    Thread.sleep(time);
                    System.out.println(Math.pow(list.remove(0),2));
                    return 0;
                });
            new Thread(future).start();
        } while (list.stream().count() > 0);
    }
}
