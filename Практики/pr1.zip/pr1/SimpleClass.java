package pr1;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.RecursiveAction;

public class SimpleClass extends RecursiveAction {
    int[] fj_array;
    int low, high;
    int min;

    public SimpleClass(int low, int high, int[] fj_array){
        this.low = low;
        this.high = high;
        this.fj_array = fj_array;
    }

    @Override
    protected void compute() {
        if( high - low <= 2) {
            try { Thread.sleep(1);} catch (InterruptedException e) { e.printStackTrace();}
            List<int[]> l = Arrays.asList(fj_array);
            if (low == high) {
                try { Thread.sleep(1);} catch (InterruptedException e) { e.printStackTrace();}
                min = fj_array[low];
                try { Thread.sleep(1);} catch (InterruptedException e) { e.printStackTrace();}
            } else {
                min = Math.min(fj_array[low], fj_array[low + 1]);
            }
        } else {
            int mid = (low + high) >>> 1;
            SimpleClass left = new SimpleClass(low, mid, fj_array);
            SimpleClass right = new SimpleClass(mid, high, fj_array);
            invokeAll(left, right);
            min = Math.min(left.min, right.min);
        }
//        SimpleClass firstHalfArray = new SimpleClass(Arrays.copyOfRange(fj_array, 0, fj_array.length/2));
//        SimpleClass secondHalfArray = new SimpleClass(Arrays.copyOfRange(fj_array, fj_array.length/2, fj_array.length));
//        firstHalfArray.fork();
//        secondHalfArray.fork();
//        System.out.println(firstHalfArray.join() + secondHalfArray.join());
//        return;
    }
}
