package pr1.t3;

import pr1.t3.handlers.*;
import java.util.Queue;

public class Handler {
    Queue<File> fileQueue;

    public Handler(Queue<File> fileQueue) {
        this.fileQueue = fileQueue;
    }

    public void Handle(){
        File file = fileQueue.poll(); //для извлечения или извлечения и удаления элемента, присутствующего в начале

        if (file == null) return;
        switch(file.f_type) {
            case "XML":
                new Thread(() -> XMLHandler.HandleFile(file)).start();
                return;
            case "JSON":
                new Thread(() -> JSONHandler.HandleFile(file)).start();
                return;
            case "XLS":
                new Thread(() -> XLSHandler.HandleFile(file)).start();
                return;
        }
    }
}
