package pr1.t3;

import java.util.Queue;
import java.util.Random;

public class Generator {
    private static final String[] FTypes = new String[]{"XML", "JSON", "XLS"};

    Queue<File> files;
    public Generator(Queue<File> files) {
        this.files = files;
    }

    public void Generate(){
        Random random = new Random();
        while (true)
        {
            try{
                String ftype = FTypes[random.nextInt(FTypes.length)];
                int fsize = random.nextInt(90) + 10;
                Thread.sleep(random.nextInt(900) + 100);
                files.add(new File(ftype, fsize));
            } catch (IllegalStateException e) {}
            catch (InterruptedException e){
                e.printStackTrace();
            }
        }
    }
}
