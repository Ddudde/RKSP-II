package pr1.t3.handlers;

import pr1.t3.File;
import pr1.t3.XHandler;

public class JSONHandler {
    public static void HandleFile(File file) {
        try {
            Thread.sleep(file.f_size*7);
            System.out.println(file.f_type);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
