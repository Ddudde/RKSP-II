package pr1.t3;

public class File {
    public String f_type;
    public int f_size;

    public File(String f_type, int f_size) {
        this.f_type = f_type;
        this.f_size = f_size;
    }
}
