package pr1.t3;

import java.util.concurrent.ArrayBlockingQueue;

public class Task3 {
    public static void main(String[] args) {
        ArrayBlockingQueue<File> fileQueue = new ArrayBlockingQueue<File>(5);
        Generator gen = new Generator(fileQueue);
        Handler handler = new Handler(fileQueue);

        while (true) {
            if (fileQueue.isEmpty())
                new Thread(() -> gen.Generate()).start();
            else
                new Thread(() -> handler.Handle()).start();
        }
    }
}