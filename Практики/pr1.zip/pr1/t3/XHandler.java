package pr1.t3;

public interface XHandler {
    public static void HandleFile(File file) {
        try {
            Thread.sleep(file.f_size*7);
            System.out.println(file.f_type);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

