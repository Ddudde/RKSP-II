package pr1;

import java.util.Random;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;

class ThreadMin implements Runnable {
    private Thread thr;
    private int[] thr_array;
    private Integer thr_min;

    public ThreadMin(int[] array) {
        thr_array = array;
        thr = new Thread(this, "Thread1.");
        thr.start();
    }

    @Override
    public void run() {
        Integer t_min = thr_array[0];
        for (int i = 0; i < thr_array.length; i++) {
            if (thr_array[i] < t_min) {
                try { Thread.sleep(1);} catch (InterruptedException e) { e.printStackTrace();}
                t_min = thr_array[i];
                try { Thread.sleep(1);} catch (InterruptedException e) { e.printStackTrace();}
            } else { try { Thread.sleep(1);} catch (InterruptedException e) { e.printStackTrace();}
            }
        }
        thr_min = t_min;
    }

    public Thread getThread() { return thr;}
    public Integer getMin() { return thr_min;}
}

public class Task1 {
    //Вариант 20. 20%3 = 2. Поиск минимального элемента в массиве

    public static final int SIZE = 10000;

    private static int findMin(int[] array) throws InterruptedException {
        int min = array[0];
        for (int i = 0; i < array.length; i++) {
            if (array[i] < min) {
                Thread.sleep(1);
                min = array[i];
                Thread.sleep(1);
            } else
                Thread.sleep(1);
        }
        return min;
    }

    public static void main(String[] args) throws InterruptedException {
        Random generate = new Random();
        int[] arr = new int[SIZE];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = generate.nextInt();
        }
        //Последовательно
        long time = System.nanoTime();
        Integer min_1 = findMin(arr);
        long end_time = System.nanoTime();
        long time1 = TimeUnit.MILLISECONDS.convert(end_time-time, TimeUnit.NANOSECONDS);
        //С использованием многопоточности
        time = System.nanoTime();
        ThreadMin thread_1 = new ThreadMin(arr);
        ThreadMin thread_2 = new ThreadMin(arr);
        try {
            thread_1.getThread().join();
            thread_2.getThread().join();
        } catch (InterruptedException e) {
           System.out.println("Error");
        }
        end_time = System.nanoTime();
        long time2 = TimeUnit.MILLISECONDS.convert(end_time-time, TimeUnit.NANOSECONDS);
        // использованием ForkJoin
          time = System.nanoTime();
          SimpleClass sClass = new SimpleClass(0, arr.length, arr);
          ForkJoinPool fjp = new ForkJoinPool();
          fjp.invoke(sClass);
          end_time = System.nanoTime();
          long time3 = TimeUnit.MILLISECONDS.convert(end_time-time, TimeUnit.NANOSECONDS);
          System.out.println("First example: min = " + min_1 + "; время поиска: " + time1 + " мс");
          System.out.println("Second example (w/Threads): min = " + thread_1.getMin()  + "; время поиска: " + time2 + " мс");
          System.out.println("Third example (w/ForkJoin): min = " + sClass.min  + "; время поиска: " + time3 + " мс");
//    }
    }
}
