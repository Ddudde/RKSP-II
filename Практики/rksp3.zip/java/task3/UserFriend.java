package task3;

public class UserFriend {
    int userId;
    int friendId;

    public int getUserId() {
        return userId;
    }

    public UserFriend(int userId, int friendId) {
        this.userId = userId;
        this.friendId = friendId;
        System.out.println("Create a friend: id = " + userId
                + "; FriendId = " + friendId);
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getFriendId() {
        return friendId;
    }

    public void setFriendId(int friendId) {
        this.friendId = friendId;
    }
}
