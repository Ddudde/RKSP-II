package task3;

import io.reactivex.*;
import java.util.ArrayList;
import java.util.List;

public class FriendGen {
    private static final List<UserFriend> userFriends = new ArrayList<>();

    public static int rnd(int min, int max) {
        max -= min;
        return (int) (Math.random() * ++max) + min;
    }

    private static void printFriends(Observable<UserFriend> UFObservable) {
        UFObservable.forEach( userFriend -> {
            System.out.println("UserId: " + userFriend.getUserId()
                    + "; FriendId: " + userFriend.getFriendId());
        });
    }

    private static UserFriend createUF(int id, int friendId) {
        UserFriend userFriend = new UserFriend(id, friendId);
        return userFriend;
    }

    private static Observable<UserFriend> getFriends (int userId) {
        List<UserFriend> out = new ArrayList<>();
        userFriends.forEach(userFriend -> {
            if (userFriend.getUserId() == userId) {
                out.add(userFriend);
            }
        });
        return Observable.fromCallable(() -> out.get(0));
    }

    public static void main(String[] args) {
        for (int i = 1; i < 8; i++) userFriends.add(createUF(i, rnd(1, 6)));
        printFriends(getFriends(5));
    }
}
