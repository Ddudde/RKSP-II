package task4;

import io.reactivex.*;

public class File {
    public int FileSize;
    public String FileType;

    public File( String fileType,int fileSize) {
        FileSize = fileSize;
        FileType = fileType;
    }
}
