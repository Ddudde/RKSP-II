package task4;

import io.reactivex.*;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;

public class JSONHandler {
    public static Observer observer = new Observer() {
        @Override
        public void onError(Throwable throwable) {}
        @Override
        public void onComplete() {}
        @Override
        public void onSubscribe(@NonNull Disposable disposable) {}

        @Override
        public void onNext(Object o) {
            System.out.println(((File)o).FileType + " is creating");
        }
    };

    public static void HandleFile(File file)
    {
        try {
            Thread.sleep(file.FileSize*7);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

