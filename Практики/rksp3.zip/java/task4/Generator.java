package task4;

import java.util.*;

public class Generator {
    Queue<File> Files;
    private static final String[] FileTypes = new String[]{ "XML", "JSON", "XLS" };

    public Generator(Queue<File> files) { Files = files; }

    public void Generate() {
        Random rnd = new Random();
        while (true)
        {
            try {
                Thread.sleep(rnd.nextInt(900) + 100);
                Files.add(new File(
                        FileTypes[rnd.nextInt(FileTypes.length)],
                        rnd.nextInt(90) + 10));
            } catch (IllegalStateException e)
            {
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }
}

