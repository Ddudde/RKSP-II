package task4;

import java.util.concurrent.ArrayBlockingQueue;

public class Main {
    public static void main(String[] args)
    {
        ArrayBlockingQueue<File> fileQueue = new ArrayBlockingQueue<File>(5);
        Generator gn = new Generator(fileQueue);
        Handler hd = new Handler(fileQueue);

        while (true)
        {
            if (fileQueue.isEmpty()) new Thread(() -> gn.Generate()).start();
            else new Thread(() -> hd.Handle()).start();
        }
    }
}
