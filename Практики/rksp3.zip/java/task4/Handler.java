package task4;

import io.reactivex.*;
import java.util.Queue;

public class Handler {
    Queue<File> FileQueue;

    public Handler(Queue<File> fileQueue) { FileQueue = fileQueue; }

    public void Handle()
    {
        File file = FileQueue.poll();
        if (file == null)
            return;
        switch (file.FileType) {
            case "XML": Observable.fromCallable(() -> file).subscribe(XMLHandler.observer);
                return;
            case "JSON": Observable.fromCallable(() -> file).subscribe(JSONHandler.observer);
                return;
            case "XLS": Observable.fromCallable(() -> file).subscribe(XLSHandler.observer);
                return;
        }
    }
}

