package task1;

import io.reactivex.*;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Main {
    public static int rnd(int min, int max) {
        max -= min;
        return (int) (Math.random() * ++max) + min;
    }

    public static void main(String[] args) {
        //Сигнализация
        Observer observer = new Observer() {
            @Override
            public void onError(Throwable throwable) {
            }
            @Override
            public void onComplete() {
            }
            @Override
            public void onSubscribe(@NonNull Disposable disposable) {
            }
            @Override
            public void onNext(Object obj) {
                int[] a = (int[]) obj;
                System.out.println("Temp: " + a[0] + "; CO2: " + a[1]);
                if (a[0] > 25 && a[1] > 70)
                    System.out.println("Alarm!!!!!");
                else if(a[0] > 25)
                    System.out.println("Temperature is high");
                else if(a[1] > 70)
                    System.out.println("CO2 is high");
                System.out.println("##########");
            }
        };

        Random random = new Random();
        Observable.fromCallable(() -> 1)
                .repeat()
                .map(rnd -> new int[]{rnd(15, 30), rnd(30, 100)})
                .take(2l, TimeUnit.SECONDS)
                .subscribe(observer);
    }
}
