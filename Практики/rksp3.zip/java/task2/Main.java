package task2;

import io.reactivex.*;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {
        Observer observer = new Observer() {
            @Override
            public void onError(Throwable throwable) {}
            @Override
            public void onComplete() {}
            @Override
            public void onSubscribe(@NonNull Disposable disposable) {}

            @Override
            public void onNext(Object obj) {
                System.out.println("Task 1");
                Stream st = (Stream) obj;
                st.filter(i -> (Integer) i > 500).forEach(i -> System.out.print("    " + i));
                }
            };

        Random random = new Random();

        List<Integer> list1 = new ArrayList();
        for (int i = 0; i < 1000; i++) list1.add(random.nextInt(1000));
        Observable.fromCallable(() -> list1.stream()).subscribe(observer);


        Observer observer2 = new Observer() {
            @Override
            public void onError(Throwable throwable) {}
            @Override
            public void onComplete() {}
            @Override
            public void onSubscribe(@NonNull Disposable disposable) {}

            @Override
            public void onNext(Object obj) {
                System.out.println("\nTask 2");
                Stream<Integer> newstream;
                Stream[] st = (Stream[]) obj;
                newstream = Stream.concat(st[0], st[1]);
                newstream.forEach(i -> System.out.print("    " + i));
            }
        };

        List<Integer> list2 = new ArrayList();
        for (int i = 0; i < 1000; i++) list2.add(random.nextInt(1000));
        Observable.fromCallable(() -> new Stream[]{list1.stream(), list2.stream()}).subscribe(observer2);

        Observer observer3 = new Observer() {
            @Override
            public void onError(Throwable throwable) {}
            @Override
            public void onComplete() {}
            @Override
            public void onSubscribe(@NonNull Disposable disposable) {}

            @Override
            public void onNext(Object obj) {
                Stream st = (Stream) obj;
                Integer last = (Integer) st.reduce((a, b) -> b).orElse(null);
                System.out.println("\nLast elem: " + last);
            }
        };

        System.out.println("\nTask3");
        List<Integer> list3 = new ArrayList();
        for (int i = 0; i < 10; i++) {
            Integer x = random.nextInt(1000);
            list3.add(x);
            System.out.print("  " + x);
        }
        Observable.fromCallable(() -> list3.stream()).subscribe(observer3);
    }
}
